export const FEMALE_AURAS = [
  "Old Money Heiress", "Men Fall Too Fast", "Barbie Doll Energy", "Pinterest Queen",
  "Rich Girl Summer", "Unreachable Crush", "Luxury Wife Energy", "Paris Fashion Week Energy",
  "Campus Heartbreaker", "Main Character Syndrome", "Soft Life Era", "That Girl Energy",
  "Dark Feminine Rising", "Ethereal Dream Girl", "Quiet Luxury Icon", "Cottage Core Princess",
  "City Girl Energy", "It Girl Energy", "CEO in the Making", "Girl Next Door Glow Up",
  "Mystery Girl Vibes", "Aesthetic Girlie", "Vintage Soul Energy", "Baddie with Depth",
  "Muse Energy", "Art Hoe Awakening", "Romantic Era Girl", "Power Couple Material",
  "Soft Spoken Dangerous", "The One Who Got Away", "Chaotic Feminine Energy", "Goddess Era",
  "Midnight Muse", "Golden Hour Girl", "That Friend Everyone Wants", "Effortlessly Cool",
  "Untouchable Energy", "Elegance Personified", "Boho Luxe Vibes", "Coquette Era",
  "Dark Academia Girlie", "Y2K Revival Queen", "Indie Film Protagonist", "Ballet Core Energy",
  "Minimalist Chic", "Maximalist Queen", "Coastal Grandmother But Make It Fashion",
  "Corporate Baddie", "Free Spirit Energy", "Wanderlust Aesthetic"
]

export const MALE_AURAS = [
  "Lover Boy", "Heartthrob", "Future CEO", "Mafia Romance Lead", "Golden Retriever Boy",
  "Gym Crush", "Campus Legend", "Trust Fund Trouble", "Rich Friend Everyone Wants",
  "Dangerous Charmer", "The Mysterious One", "Softboy Energy", "Dark Horse Energy",
  "The Cool Older Brother", "Brooding Artist", "Gentleman Player", "The Romantic",
  "Charismatic Leader", "Underdog Champion", "The Intellectual", "Athletic God Energy",
  "Rebel with Cause", "The Charmer", "Midnight Villain Era", "Old Soul Energy",
  "The Protector", "Alpha Energy Redefined", "Quiet Storm", "The Visionary",
  "Smooth Operator", "The Enigma", "Silver Spoon Rebel", "Adventure Seeker",
  "Creative Genius", "The Renaissance Man", "Grunge Era Icon", "Skater Boy Grown Up",
  "The Overthinker", "Moody Artist Energy", "Tech Bro but Make It Aesthetic",
  "Street Style King", "Vintage Soul", "The Philosopher", "Dark Academic",
  "Sunrise Guy Energy", "The Nurturer", "Wild Card Energy", "The Storyteller",
  "Complex Protagonist", "The One You Can't Forget"
]

export const NEUTRAL_AURAS = [
  "Main Character", "Cult Favorite", "Secret Celebrity", "The One Everyone Remembers",
  "Human Pinterest Board", "Walking Aesthetic", "Undefined but Unforgettable",
  "Genre-Defying Energy", "The Vibe Itself", "Chronically Online Icon",
  "Alternative Universe Protagonist", "The Rare Find", "Niche Famous",
  "Too Cool to Label", "The Trendsetter", "Quietly Iconic", "The Anomaly",
  "Collector of Experiences", "The Shapeshifter", "Ethereal Being Energy"
]

export const TV_CHARACTERS = [
  { name: "Blair Waldorf", show: "Gossip Girl", emoji: "👸" },
  { name: "Serena van der Woodsen", show: "Gossip Girl", emoji: "✨" },
  { name: "Chuck Bass", show: "Gossip Girl", emoji: "🥃" },
  { name: "Damon Salvatore", show: "The Vampire Diaries", emoji: "🖤" },
  { name: "Stefan Salvatore", show: "The Vampire Diaries", emoji: "🌹" },
  { name: "Maddy Perez", show: "Euphoria", emoji: "💅" },
  { name: "Rue Bennett", show: "Euphoria", emoji: "🌙" },
  { name: "Cassie Howard", show: "Euphoria", emoji: "🌸" },
  { name: "Daenerys Targaryen", show: "Game of Thrones", emoji: "🐉" },
  { name: "Jon Snow", show: "Game of Thrones", emoji: "⚔️" },
  { name: "Wednesday Addams", show: "Wednesday", emoji: "🕷️" },
  { name: "Joe Goldberg", show: "You", emoji: "📚" },
  { name: "Anthony Bridgerton", show: "Bridgerton", emoji: "🌺" },
  { name: "Penelope Featherington", show: "Bridgerton", emoji: "💛" },
  { name: "JJ Maybank", show: "Outer Banks", emoji: "🌊" },
  { name: "John B", show: "Outer Banks", emoji: "🏄" },
  { name: "Rachel Green", show: "Friends", emoji: "👗" },
  { name: "Ross Geller", show: "Friends", emoji: "🦕" },
  { name: "Harvey Specter", show: "Suits", emoji: "💼" },
  { name: "Thomas Shelby", show: "Peaky Blinders", emoji: "🎩" },
  { name: "Otis Milburn", show: "Sex Education", emoji: "🎙️" },
  { name: "Maeve Wiley", show: "Sex Education", emoji: "📖" },
  { name: "Steve Harrington", show: "Stranger Things", emoji: "🏐" },
  { name: "Eleven", show: "Stranger Things", emoji: "🔮" },
]
